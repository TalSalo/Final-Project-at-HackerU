# import libraries
import pandas as pd
import numpy as np
import sqlalchemy as sa
from sqlalchemy import create_engine
import requests

########################################################################

# api section


def get_currency(date):
    website = "app.currencyapi.com"
    api_key = "cur_live_nU0AlCwcagOd9h1ntmdnK9jDH6BFxCLvIsdhg4aZ"

    from_currency = "USD"
    to_currency = "ILS"
    amount = 1

    url = f"https://api.currencyapi.com/v3/historical?apikey={api_key}&currencies={to_currency}&date={date}"

    response = requests.get(url=url)
    response.raise_for_status()
    data = response.json()
    currency_df = pd.DataFrame(data=data["data"])
    currency_value = currency_df.iloc[1, 0]
    return currency_value

############################################################

# import and read the files
raw_department = pd.read_csv("raw-department.txt", delimiter="-")
budget1 = pd.read_json("raw-department-budget.txt", orient="records", lines=True)
budget2 = pd.read_json("raw-department-budget2.txt")

# connect to supabase
hostname = 'aws-0-us-west-1.pooler.supabase.com'
database = 'chinook'
username = 'postgres.xzrpfggwcexwdzaxhnyu'
password = 'Gersh123!123'
port = '6543'
engine = create_engine(f'postgresql+psycopg2://{username}:{password}@{hostname}:{port}/{database}')
engine.connect()

# concatenating two of three dataframes
Department_Budget = pd.concat([budget1, budget2]).reset_index(drop=True)
# merging with the third dataframe
Departments = raw_department.merge(Department_Budget, how='left', on='department_id')
# creating group by name and id
department_budget = Departments.groupby(['department_id', 'department_name'])['budget'].sum().reset_index()
# send to supabase on stg tables
department_budget.to_sql("dwh.department_budget", engine, if_exists='replace', index=False)

##################################################################################
# read stg invoice and extract date of invoices
query = 'select date(invoicedate) from stg.invoice as i'
dim_currency = pd.read_sql(query, engine)

# loop through data_key dataframe and connect to api currency by date
for i in range(len(dim_currency)):
    if i < 10:
        specific = dim_currency.iloc[i, 0]
        dim_currency["exchange_rate"] = get_currency(specific)

# remove duplications
dim_currency.drop_duplicates(inplace=True)
# send to dwh

dim_currency.to_sql("dwh.Dim_currency", con=engine, if_exists='replace', index=False)
