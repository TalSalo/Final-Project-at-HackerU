{{ config(materialized='ephemeral') }}
with length_in_seconds as (
    select trackid
    ,milliseconds/1000 as track_length_in_seconds
    from {{ source ('stg','track') }} as t
)
select * 
 ,to_char((track_length_in_seconds||' second')::interval,'MI:SS') as track_length
from length_in_seconds