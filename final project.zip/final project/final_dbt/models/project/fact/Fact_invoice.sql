{{ config(materialized='incremental',unique_key='invoiceid',
    pre_hook="{{log_pre_hook('4')}}",
    post_hook="{{log_post_hook('4')}}"
)}}
select 
invoiceid
,customerid
,invoicedate
,total
,last_update
from {{ source ('stg','invoice') }}  