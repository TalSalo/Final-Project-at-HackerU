{{ config(materialized='incremental',unique_key='invoicelineid',
    pre_hook="{{log_pre_hook('5')}}",
    post_hook="{{log_post_hook('5')}}"
)}}

select * 
from {{ source ('stg','invoiceline') }} 