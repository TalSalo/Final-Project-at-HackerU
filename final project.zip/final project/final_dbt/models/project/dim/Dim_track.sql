{{config (materialized = "table"
,pre_hook=["{{log_pre_hook(6)}}"]
,post_hook="{{log_post_hook(6)}}"
)}}

select 
t.trackid 
,t."name" as track_name
,t.composer
,eph.track_length_in_seconds
,eph.track_length
,t.bytes
,t.unitprice
,a.albumid
,a.title
,ar.artistid
,ar."name" as artist_name
,mt.mediatypeid
,mt."name" as mediatype_name
,g.genreid
,g."name" as genre_name
,t.last_update as track_last_update
FROM {{ source ('stg','track') }} as t 
inner join {{ source ('stg','album') }} as a on a.albumid = t.albumid
inner join {{ source ('stg','artist') }} as ar on ar.artistid = a.artistid
inner join {{ source ('stg','mediatype') }} as mt on t.mediatypeid = mt.mediatypeid
inner join {{ source ('stg','genre') }} as g on t.genreid = g.genreid
inner join {{ref('track_length')}} as eph on t.trackid = eph.trackid