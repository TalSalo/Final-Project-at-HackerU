{{ config(materialized='incremental',unique_key='playlistid'
,pre_hook=["{{log_pre_hook(3)}}"]
,post_hook="{{log_post_hook(3)}}"
) }}

select 
p.playlistid
,p."name" as playlist_name
,p.last_update as playlist_last_update
,pt.trackid
,pt.last_update as playlist_track_last_update
from {{ source ('stg','playlisttrack') }} as pt
inner join {{ source ('stg','playlist')}} as p on p.playlistid=pt.playlistid