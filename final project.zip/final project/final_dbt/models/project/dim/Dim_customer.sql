{{config (materialized = "table"
,pre_hook=["{{log_pre_hook(1)}}"]
,post_hook="{{log_post_hook(1)}}"
)}}

select 
customerid
,initcap(firstname) as firstname
,initcap(lastname) as lastname
,company
,address
,city
,state
,country
,postalcode
,phone
,fax
,email
,split_part(email,'@',2) as emaildomain
,supportrepid
,last_update
from {{ source ('stg','customer')}} as c