{{config (materialized = "table"
,pre_hook=["{{log_pre_hook(2)}}"]
,post_hook="{{log_post_hook(2)}}"
) }}

select 
e.*
,db.department_name
,db.budget
,date_part('year',now())-date_part('year',e.hiredate) as employment_time
,split_part(email,'@',2) as emaildomain
,case when e.employeeid in (select distinct reportsto from {{ source ('stg','employee') }}) then 1 else 0 end as is_manager
from {{ source ('stg','employee') }} as e
inner join {{ source ('stg','department_budget') }} as db on e.departmentid = db.department_id