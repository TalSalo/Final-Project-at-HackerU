{%macro log_pre_hook(dbt_id)%}
insert into chinook.dwh.dbt_log (dbt_id,dbt_model_desc,dbt_sub_id,start_at,end_at,status,dbt_total_sec)
values
(
{{dbt_id}}
,'{{this}}'
,(select case when max(dbt_sub_id) is not null then max(dbt_sub_id)+1 else 1 end from chinook.dwh.dbt_log where dbt_id = {{dbt_id}})
,now()
,null
,(select case when max(end_at) is null then 'failed' else 'started' end from chinook.dwh.dbt_log where dbt_id = {{dbt_id}})
,null
)
;
commit;
{% endmacro %}