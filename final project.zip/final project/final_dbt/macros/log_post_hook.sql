{% macro log_post_hook(dbt_id) %}
update chinook.dwh.dbt_log
set
end_at = now()
,dbt_total_sec = age(now(),start_at)
,status = (select case when max(end_at) is not null then 'finished' else 'failed' end from chinook.dwh.dbt_log where dbt_id = {{dbt_id}})
where dbt_sub_id = (select max(dbt_sub_id) from chinook.dwh.dbt_log where dbt_id = {{dbt_id}})
and dbt_id = {{dbt_id}};
{% endmacro %}